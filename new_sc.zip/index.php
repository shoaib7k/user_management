<?php session_start(); ?>
<html>

<head>
  <?php include "head.php"; ?>
</head>

<body>
  <?php include "header.php" ?>



  <div class="container">
    <div class="card-deck mb-3 text-center">
      <div class="card mb-4 box-shadow">
        <div class="card-header">
      
        
        </div>
      </div>

    </div>


  </div>

  <?php include 'footer.php';?>
</body>

</html>