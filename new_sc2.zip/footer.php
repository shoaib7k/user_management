<footer style="
   bottom:0;
   width:100%;
   height:40px;
   background:#1D7852;
   color: #F8F8F8;
   position:fixed;">
    <p>@Radeburger Fensterbau GmbH</p>
</footer>