  <?php
   $db_connection = pg_connect("host=localhost port=5432 dbname=Intranet user=postgres password=postgres");
?>